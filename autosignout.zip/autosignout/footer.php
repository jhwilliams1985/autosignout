<?php
if(isset($user) && $user->isLoggedIn()){ ?>
    <div id="Session_TimeOut" style="display: none;">
        <div class="card text-center">
            <div class="card-body">
                <h5 class="card-title">Session Timeout</h5>
                <p class="card-text">You're being timed-out out due to inactivity.</br>Please choose to stay signed in or to logoff.</br>Otherwise, you will be logged off automatically.</p>
                <a onclick="resetTimer();" class="btn btn-primary btn-lg active" role="button" aria-pressed="true">Continue</a>
                <a onclick="IdleTimeout()" class="btn btn-danger btn-lg active" role="button" aria-pressed="true">Sign out</a>
            </div>
        </div>
    </div>
    <script>
        var warningTimeout = 840000; // 840000
        var timoutNow = 60000; // 60000
        var warningTimerID,timeoutTimerID;
        var logoutUrl = '<?=$us_url_root."users/logout.php"?>';
        var x = document.getElementById("Session_TimeOut");

        function startTimer() {
            // window.setTimeout returns an Id that can be used to start and stop a timer
            warningTimerID = window.setTimeout(warningInactive,warningTimeout);
        }

        function warningInactive() {
            window.clearTimeout(warningTimerID);
            timeoutTimerID = window.setTimeout(IdleTimeout, timoutNow);
            signout();
        }

        function signout(){
            if (x.style.display === "none") {
                x.style.display = "block";
            }
        }

        function resetTimer() {
            window.clearTimeout(timeoutTimerID);
            window.clearTimeout(warningTimerID);
            if (x.style.display === "block") {
                x.style.display = "none";
            }
            startTimer();
        }

        function setupTimers () {
            document.addEventListener("keypress", resetTimer, false);
            startTimer();
        }

        // Logout the user.
        function IdleTimeout() {
            window.location = logoutUrl;
        }

        $(document).ready(function(){
            setupTimers();
        });
    </script>
<?php } ?>