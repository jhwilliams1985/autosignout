If you have example php files they can go here.
This is also a good place to store files that need to be copied during install.
Please make sure any files in this folder cannot be run if they are called directly.  
